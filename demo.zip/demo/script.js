document.addEventListener('DOMContentLoaded', () => {
    // Select all anchor links with href starting with #
    const scrollLinks = document.querySelectorAll('a[href^="#"]');
    const image = document.querySelector('.slide-image');

    if (image) { // Ensure the image element exists
        let pos = 0;
        const maxPos = 100; // Adjust this value according to your need

        function slideImage() {
            pos += 1; // Adjust the speed by changing this value
            if (pos > maxPos) pos = 0;
            image.style.transform = `translateX(${pos}px)`;
        }

        setInterval(slideImage, 50);
    } else {
        console.warn('No element with class "slide-image" found.');
    }

    scrollLinks.forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent default anchor click behavior

            const targetId = this.getAttribute('href').substring(1); // Get the target ID
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                // Smooth scroll to the target element
                targetElement.scrollIntoView({
                    behavior: 'smooth', // Smooth scroll
                    block: 'start' // Align scroll to the top of the element
                });
            } else {
                console.warn(`Element with ID "${targetId}" not found.`);
                // Optional: You could display an error message or handle this case in other ways
            }
        });
    });
});